package com.example.chatapp

class UserModel (
    val name : String? = null,
    val password : String? = null,
    val uuid : String? = null
)